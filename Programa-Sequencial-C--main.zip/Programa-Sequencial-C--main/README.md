Programas Básicos escrito em C++ com Programação Sequencial
